//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by osmozilla.rc
//
#define IDD_MAIN                        101
#define IDC_BUTTON_GO                   1002
#define IDC_STATIC_UA                   1003
#define IDC_BUTTON1                     1005
#define IDC_BUTTON_DONT                 1005

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
