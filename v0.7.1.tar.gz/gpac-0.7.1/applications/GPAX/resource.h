//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by GPAX.rc
//
#define IDS_PROJNAME                    100
#define IDB_GPAXPLUGIN                  101
#define IDR_GPAXPLUGIN                  102
#define IDS_TITLEGPAXProp               103
#define IDS_HELPFILEGPAXProp            104
#define IDS_DOCSTRINGGPAXProp           105
#define IDR_GPAXPROP                    106
#define IDD_GPAXPROP                    107
#define IDC_EDIT_URLs                   201

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        202
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         202
#define _APS_NEXT_SYMED_VALUE           108
#endif
#endif
