#!/bin/sh
rm -f config/config.h
rm -f Makefile doc/Makefile misc/Makefile test/Makefile
rm -f config.log config.status
rm -rf autom4te.cache
