#ifndef NASM_VERSION_H
#define NASM_VERSION_H
#define NASM_MAJOR_VER      3
#define NASM_MINOR_VER      1
#define NASM_SUBMINOR_VER   0
#define NASM_PATCHLEVEL_VER 0
#define NASM_VERSION_ID     0x03010000
#define NASM_VER            "3.01"
#endif /* NASM_VERSION_H */
